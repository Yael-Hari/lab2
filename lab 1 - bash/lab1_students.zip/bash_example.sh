#!/bin/bash
echo "this is my first bash script"
echo "I can write into files" > test.txt
cp test.txt test1.txt
echo "I am done, lets see what I have here"
ls
